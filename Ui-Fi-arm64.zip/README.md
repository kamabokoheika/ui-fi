# Ui-Fi

タスクトレイに常駐して Discord の Rich Presence を表示する Windows アプリです。インストールは不要で、`Ui-Fi.exe` を実行するだけで使えます。

[日本語](#日本語) / [英語 English](#english) / [韓国語 한국어](#한국어)

## 日本語

### 起動

1. zip を展開し、`Ui-Fi.exe` をダブルクリックします（インストールは不要です）
2. Discord の**デスクトップアプリ**を起動すると、プロフィールに表示されます
3. タスクトレイにカエルのアイコンが常駐します。見えない場合は `^` をクリックしてオーバーフローを開き、ピン留めしてください

### 使い方

| 操作 | 動作 |
| --- | --- |
| アイコンをダブルクリック | 設定画面を開く |
| 右クリック → **Discord RPC を有効にする** | RPC の ON/OFF |
| 右クリック → **言語/lang/언어** | 表示言語の切り替え |
| 右クリック → **終了** | アプリを終了 |

右クリックメニューの先頭に、接続状態（接続済み / Discord待機中 / 接続中 / オフ / エラー）が表示されます。

### 言語

日本語 / English / 韓国語 に対応しています。トレイメニューの **言語/lang/언어**、または設定画面から切り替えられます。

### 設定

表示内容はトレイアイコンをダブルクリックして開く設定画面から変更できます。
設定ファイルは `%APPDATA%\Ui-Fi\config.json` に保存されます。

## English

A Windows tray app that shows Discord Rich Presence. No installation — just run `Ui-Fi.exe`.

### Getting started

1. Extract the zip and double-click `Ui-Fi.exe`
2. Start the Discord **desktop app** and the presence appears on your profile
3. A frog icon stays in the system tray. If you can't see it, click `^` and pin it

### Usage

| Action | Result |
| --- | --- |
| Double-click the icon | Open settings |
| Right-click → **Enable Discord RPC** | Toggle RPC on/off |
| Right-click → **Language/lang/언어** | Change the UI language |
| Right-click → **Exit** | Quit the app |

The connection status (Connected / Waiting for Discord / Connecting / Off / Error) is shown at the top of the right-click menu.

### Language

The UI supports Japanese / English / Korean. Switch it from **Language/lang/언어** in the tray menu or from the settings window.

### Configuration

Change what's shown from the settings window (double-click the tray icon).
The config file is stored in `%APPDATA%\Ui-Fi\config.json`.

## 한국어

Discord Rich Presence를 표시하는 Windows 트레이 상주 앱입니다. 설치가 필요 없으며 `Ui-Fi.exe`를 실행하면 바로 사용할 수 있습니다.

### 실행

1. zip의 압축을 풀고 `Ui-Fi.exe`를 더블클릭합니다
2. Discord **데스크톱 앱**을 실행하면 프로필에 표시됩니다
3. 트레이에 개구리 아이콘이 상주합니다. 보이지 않으면 `^`를 눌러 펼친 뒤 고정하세요

### 사용 방법

| 동작 | 결과 |
| --- | --- |
| 아이콘 더블클릭 | 설정 화면 열기 |
| 오른쪽 클릭 → **Discord RPC 사용** | RPC 켜기/끄기 |
| 오른쪽 클릭 → **언어/lang/언어** | 표시 언어 변경 |
| 오른쪽 클릭 → **종료** | 앱 종료 |

오른쪽 클릭 메뉴 맨 위에 연결 상태(연결됨 / Discord 대기 중 / 연결 중 / 꺼짐 / 오류)가 표시됩니다.

### 언어

日本語 / English / 한국어를 지원합니다. 트레이 메뉴의 **언어/lang/언어** 또는 설정 화면에서 바꿀 수 있습니다.

### 설정

트레이 아이콘을 더블클릭해 열리는 설정 화면에서 표시 내용을 바꿀 수 있습니다.
설정 파일은 `%APPDATA%\Ui-Fi\config.json`에 저장됩니다.
